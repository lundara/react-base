import React from 'react';
import Layout from 'components/layout/layout';
import './style.scss';

class Dashboard extends React.Component {
    render() {
        return (
            <Layout>
                <div className="row mt-4">
                    <div className="col-md-12">
                        <h2 className="content-header-title float-left pr-1 mb-0">Dashboard</h2>
                    </div>
                </div>
            </Layout>
        );
    }
}

export default Dashboard;
