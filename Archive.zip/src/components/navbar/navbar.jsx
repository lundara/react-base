import React from 'react';
import { Avatar } from 'primereact/avatar';
import './style.scss';

class Navbar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <nav class="navbar navbar-expand-lg navbar-light">
                <a href="javascript:(0)" class="btn-toggle-sidebar">
                    <i class="fas fa-bars fa-lg" style={{ color: '#9a9a9a' }}></i>
                </a>
                <ul class="navbar-nav ml-auto mt-lg-0">
                    <li class="nav-item">
                        <a href="javascript:(0)" style={{ textDecoration: 'none' }} class="mr-4 button-notif">
                            <i class="fas fa-bell fa-lg" style={{ color: '#9a9a9a' }}></i>
                        </a>
                        <a href="javascript:(0)" style={{ textDecoration: 'none' }}>
                            <Avatar label="L" shape="circle" className="avatar-init" />
                        </a >
                    </li >
                </ul >
            </nav >
        );
    }
}

export default Navbar;
