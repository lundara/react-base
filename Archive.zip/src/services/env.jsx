
let env = {
    baseURL: 'http://app.panorra.com',
    publicURL: 'http://localhost:3000'
};

export default env;

